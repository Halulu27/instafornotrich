Das kommt aus meinem ersten Template<br />
Hallo <?= htmlspecialchars($name)?>
